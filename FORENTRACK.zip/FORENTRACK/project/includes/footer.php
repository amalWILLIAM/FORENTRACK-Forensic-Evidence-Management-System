<!-- start footer Area -->		
			<footer class="footer-area">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 text-center">
							<div class="single-footer-widget">
								<h6> Forensic Department | India </h6>
								<p class="footer-text">
									Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
								</p>								
							</div>
						</div>
					</div>
				</div>
			</footer>	
<!-- End footer Area -->	