<?php
	$con = mysqli_connect("localhost", "root", "", "forensic")or die("Common.php error");
	session_start();
?>